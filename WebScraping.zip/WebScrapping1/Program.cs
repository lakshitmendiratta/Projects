﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using HtmlAgilityPack;
using Newtonsoft.Json;
using System.Data.SqlClient;

//Reference - Youtube https://www.youtube.com/watch?v=B4x4pnLYMWI

namespace WebScrapping1
{
    class Program
    {
        //Capturing the scrapping data into Lists
        public static List<String> id_list = new List<String>();
        public static List<String> name_list = new List<String>();
        public static List<String> price_list = new List<String>();
        public static List<String> url_list = new List<String>();

        //Connection String
        public static string connString = @"Server = tcp:bdat1234.database.windows.net; Database=WebScrapping;User ID=BDAT;Password=Bigdata@1234;Trusted_Connection=False;Encrypt=True;";

        static void Main(string[] args)
        {
            //Console.Write(name_list.Count);
            getHtml();
            Console.ReadLine();

                     }
        //The async keyword tells the compiler that the new async functionality will be used in the method. 
        private static async void getHtml()
        {
            string Url = "https://www.amazon.in/s?k=winter+jackets&ref=nb_sb_noss";
            var httpClient = new HttpClient();
            //The await keyword ensures that nothing happens before the called asynchronous method is finished.
            var html = await httpClient.GetStringAsync(Url);
            var htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);

            //It takes all our search results in a single place
            var list1 = htmlDocument.DocumentNode.Descendants("div").
                Where(node => node.GetAttributeValue("class", "").
                Equals("s-result-list s-search-results sg-row")).ToList();
            
            //This captures the single product in the list
            var list2 = list1[0].Descendants("div").
               Where(node => node.GetAttributeValue("data-asin", "").
               Contains("B")).ToList();

            // For loop to display and write product data into the lists
            foreach (var item in list2)
            {
                //Product ID
                Console.WriteLine(item.GetAttributeValue("data-asin", ""));
                
                id_list.Add(item.GetAttributeValue("data-asin", ""));
                //Product Name
                Console.WriteLine(item.Descendants("span").
                    Where(node => node.GetAttributeValue("class", "").
                    Equals("a-size-base-plus a-color-base a-text-normal")).FirstOrDefault().InnerText);

                name_list.Add(item.Descendants("span").
                    Where(node => node.GetAttributeValue("class", "").
                    Equals("a-size-base-plus a-color-base a-text-normal")).FirstOrDefault().InnerText);

                //Product Price
                Console.WriteLine(item.Descendants("span").
                    Where(node => node.GetAttributeValue("class", "").
                    Equals("a-offscreen")).FirstOrDefault().InnerText);

                price_list.Add(item.Descendants("span").
                    Where(node => node.GetAttributeValue("class", "").
                    Equals("a-offscreen")).FirstOrDefault().InnerText);

                //To Display Indian Currency Symbol in Console output
                Console.OutputEncoding = System.Text.Encoding.UTF8;

                //Product URL

                //Console.WriteLine(item.Descendants("a").FirstOrDefault().
                // GetAttributeValue("https://www.amazon.in" + "href", "https://www.amazon.in" + "href"));

                var a = item.Descendants("a").FirstOrDefault().
                   GetAttributeValue("href", "");

                // To convert '&amp' in Console Output to '&'
                Console.WriteLine(HttpUtility.HtmlDecode("https://www.amazon.in" + a));
                url_list.Add("https://www.amazon.in" + a);
                Console.WriteLine("\n");
                

            }
            //Console.Write(name_list.Count);
            for (int i = 0; i <= id_list.Count; i++)
            {
                try
                {
                    //create the SqlConnection object
                    using (SqlConnection conn = new SqlConnection(connString))
                    {

                        //retrieve the SQL Server instance version
                        /*var id = id_list[i];
                        var name = name_list[i];
                        var price = price_list[i];
                        var url = url_list[i];*/

                        //execute the SQL Command (Insert)
                        String query = @"INSERT INTO dbo.amazon (ID, name, price, url) VALUES (@id, @name,@price,@url)";
                        //create the SqlCommand object


                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.Add("@id", System.Data.SqlDbType.NChar).Value = id_list[i];
                            cmd.Parameters.Add("@name", System.Data.SqlDbType.NChar).Value = name_list[i];
                            cmd.Parameters.Add("@price", System.Data.SqlDbType.NChar).Value = price_list[i];
                            cmd.Parameters.Add("@url", System.Data.SqlDbType.NChar).Value = url_list[i];
                            //open connection
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            //close connection
                            conn.Close();
                        }

                    }
                }
                catch (Exception ex)
                {
                    //display error message
                    Console.WriteLine("Exception: " + ex.Message);
                }
               
            }

            Console.WriteLine("Statement successfully executed.");
            getDet();
            
            /*Console.WriteLine();*/
        }


        public static void getDet()
        {
            string ID;
            string name, price, url;
            try
            {
                //sql connection object
                using (SqlConnection conn = new SqlConnection(connString))
                {

                    //retrieve the SQL Server instance version
                    string query = @"SELECT *
                                 FROM amazon
                                 ";
                    //define the SqlCommand object
                    SqlCommand cmd = new SqlCommand(query, conn);

                    //open connection
                    conn.Open();

                    //execute the SQLCommand
                    SqlDataReader dr = cmd.ExecuteReader();

                    Console.WriteLine(Environment.NewLine + "Retrieving data from database..." + Environment.NewLine);
                    Console.WriteLine("Retrieved records:");

                    //check if there are records
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            ID = dr.GetString(0);
                            name = dr.GetString(1);
                            price = dr.GetString(2);
                            url = dr.GetString(3);


                            //display retrieved record
                            Console.WriteLine("{0},{1},{2},{3}", ID, name, price, url);
                        }
                    }
                    else
                    {
                        Console.WriteLine("No data found.");
                    }

                    //close data reader
                    dr.Close();

                    //close connection
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                //display error message
                Console.WriteLine("Exception: " + ex.Message);
            }
        }
    }
}
